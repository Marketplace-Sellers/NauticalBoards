import PageManager from '../pageManager';

export default class OrderComplete extends PageManager {
    constructor() {
        super();
    }
}
