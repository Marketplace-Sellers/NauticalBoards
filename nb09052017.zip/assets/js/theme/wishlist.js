import PageManager from '../pageManager';

export default class WishList extends PageManager {
    constructor() {
        super();
    }
}
