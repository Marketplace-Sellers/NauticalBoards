import PageManager from '../pageManager';

export default class Subscribe extends PageManager {
    constructor() {
        super();
    }
}
