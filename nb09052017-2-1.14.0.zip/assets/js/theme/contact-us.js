import PageManager from '../pageManager';

export default class ContactUs extends PageManager {
    constructor() {
        super();
    }
}
