import PageManager from '../pageManager';

export default class BlogPost extends PageManager {
    constructor() {
        super();
    }
}
