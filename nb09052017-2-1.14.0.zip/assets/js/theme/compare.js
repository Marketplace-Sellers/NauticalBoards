import PageManager from '../pageManager';

export default class Compare extends PageManager {
  constructor() {
    super();
  }
}
