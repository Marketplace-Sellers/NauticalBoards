import PageManager from '../pageManager';

export default class Errors extends PageManager {
    constructor() {
        super();
    }
}
