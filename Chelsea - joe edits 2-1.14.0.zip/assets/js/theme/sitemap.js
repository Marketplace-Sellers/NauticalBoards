import PageManager from '../pageManager';

export default class SiteMap extends PageManager {
    constructor() {
        super();
    }
}
