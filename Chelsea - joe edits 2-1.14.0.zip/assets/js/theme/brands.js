import PageManager from '../pageManager';

export default class Brands extends PageManager {
    constructor() {
        super();
    }
}
